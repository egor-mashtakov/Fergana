"""
        Make copy of model, with all same parameters
        """